const API = "http://localhost:8080/api";
let currentUser = null;

function show(id){document.getElementById(id).classList.remove("hidden")}
function hide(id){document.getElementById(id).classList.add("hidden")}
function esc(v){return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

async function request(url, options={}){
  const res=await fetch(API+url,{headers:{"Content-Type":"application/json"},...options});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message||"Request failed");
  return data;
}

async function login(){
  const role=document.getElementById("role").value;
  try{
    currentUser=await request("/auth/login",{method:"POST",body:JSON.stringify({
      username:document.getElementById("username").value,
      password:document.getElementById("password").value,
      role
    })});
    hide("loginView");
    if(role==="STUDENT"){show("studentView"); await loadStudent();}
    else {show("librarianView"); await loadLibrarian();}
  }catch(e){document.getElementById("loginMsg").textContent=e.message}
}
function logout(){currentUser=null;hide("studentView");hide("librarianView");show("loginView")}

async function loadStudent(){
  const info=await request("/students/"+currentUser.id);
  document.getElementById("studentInfo").innerHTML=`
    <div class="stat"><b>Student</b><br>${esc(info.name)}</div>
    <div class="stat"><b>Reward Points</b><br>${info.rewardPoints}</div>
    <div class="stat"><b>Total Fines</b><br>₹${info.totalFine}</div>`;
  const books=await request("/books");
  document.getElementById("bookList").innerHTML=books.filter(b=>b.availableQuantity>0).map(b=>`
    <div class="book"><h4>${esc(b.title)}</h4><p>${esc(b.author)}</p>
    <p>Section: ${esc(b.section)} | Available: ${b.availableQuantity}</p>
    <button onclick="borrow(${b.id})">Borrow</button></div>`).join("")||"<p>No books available.</p>";
  const bs=await request("/borrowals/student/"+currentUser.id);
  document.getElementById("myBorrowals").innerHTML=table(bs,true);
}
async function borrow(bookId){try{await request("/borrowals/borrow",{method:"POST",body:JSON.stringify({studentId:currentUser.id,bookId})});alert("Book borrowed successfully");loadStudent()}catch(e){alert(e.message)}}
async function returnBook(id){try{const r=await request("/borrowals/"+id+"/return",{method:"POST"});alert(r.message);loadStudent()}catch(e){alert(e.message)}}

function table(rows,student){
  if(!rows.length)return "<p>No records.</p>";
  return `<table><tr><th>Book</th><th>Borrowed</th><th>Due</th><th>Returned</th><th>Fine</th><th>Reward</th>${student?"<th>Action</th>":""}</tr>`+
  rows.map(r=>`<tr><td>${esc(r.bookTitle)}</td><td>${r.borrowDate}</td><td>${r.dueDate}</td><td>${r.returnDate||"-"}</td><td>₹${r.fine}</td><td>${r.rewardPoints}</td>${student?`<td>${!r.returnDate?`<button class="success" onclick="returnBook(${r.id})">Return</button>`:"Done"}</td>`:""}</tr>`).join("")+"</table>";
}

async function loadLibrarian(){
  const s=await request("/librarian/stats");
  document.getElementById("libStats").innerHTML=Object.entries(s).map(([k,v])=>`<div class="stat"><b>${k}</b><br>${v}</div>`).join("");
  const books=await request("/books");
  document.getElementById("allBooks").innerHTML=`<table><tr><th>Title</th><th>Author</th><th>Section</th><th>Total</th><th>Available</th><th>Action</th></tr>`+
    books.map(b=>`<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${esc(b.section)}</td><td>${b.quantity}</td><td>${b.availableQuantity}</td><td><button class="danger" onclick="removeBook(${b.id})">Remove</button></td></tr>`).join("")+"</table>";
  const students=await request("/students");
  document.getElementById("students").innerHTML=`<table><tr><th>Name</th><th>Username</th><th>Rewards</th><th>Fine</th><th>Action</th></tr>`+
    students.map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.username)}</td><td>${s.rewardPoints}</td><td>₹${s.totalFine}</td><td><button class="danger" onclick="removeStudent(${s.id})">Remove</button></td></tr>`).join("")+"</table>";
  const bs=await request("/borrowals");
  document.getElementById("borrowals").innerHTML=table(bs,false);
}
async function addBook(){
  try{await request("/books",{method:"POST",body:JSON.stringify({title:bookTitle.value,author:bookAuthor.value,section:bookSection.value,quantity:+bookQty.value})});alert("Book added");loadLibrarian()}catch(e){alert(e.message)}
}
async function removeBook(id){if(confirm("Remove book?")){try{await request("/books/"+id,{method:"DELETE"});loadLibrarian()}catch(e){alert(e.message)}}}
async function addStudent(){
  try{await request("/students",{method:"POST",body:JSON.stringify({name:studentName.value,username:studentUsername.value,password:studentPassword.value})});alert("Student added");loadLibrarian()}catch(e){alert(e.message)}
}
async function removeStudent(id){if(confirm("Remove student?")){try{await request("/students/"+id,{method:"DELETE"});loadLibrarian()}catch(e){alert(e.message)}}}
